<script src="/frontend/admin/ckeditor/ckeditor.js"></script>
<script src="/frontend/admin/ckeditor/functionck.js"></script>

<link rel="stylesheet" type="text/css" href="{{asset('/frontend/admin/select2/select2.min.css')}}">

<script src="{{asset('/frontend/admin/select2/select2.min.js')}}"></script>

<footer class="main-footer">
	 <div class="container-fluid">
	  <div class="row">
	    <div class="col-sm-6">
	      <p>HOST COLLECTION &copy; 2019</p>
	    </div>
	    <div class="col-sm-6 text-right">
	      <!-- <p>Design by <a href="" class="external">Phan Trọng Hiển</a></p> -->
	    </div>
	  </div>
</div>
</footer>
@yield('script_js')