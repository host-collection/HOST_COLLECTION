<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class NewsCate extends Model
{
   protected $table = "dobo_newscate";
   protected $primary = "id";
   protected $timestamp = true;
}
